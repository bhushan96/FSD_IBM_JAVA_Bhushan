package com.ibm.mra;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.platform.commons.annotation.Testable;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ibm.mra.beans.Account;
import com.ibm.mra.dao.AccountDao;
import com.ibm.mra.dao.AccountDaoImpl;
import com.ibm.mra.service.AccountService;
import com.ibm.mra.service.AccountServiceImpl;

@TestInstance(Lifecycle.PER_CLASS)
public class AppTest{

	ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("appContext.xml");
	AccountService accountService = context.getBean("accountService", AccountServiceImpl.class);

	@Test
	@Disabled
	void testGetAccountDetails() {
		Account expected=new Account("Prepaid","Vaishali",521.0);
		Account actual=accountService.getAccountDetails("9010210131");
		assertEquals(expected, actual);
	}
	
	@Test
	void testRechargeAccount() {
		int expected=1;
		int actual=accountService.rechargeAccount("9932012345",111);
		assertEquals(expected, actual);
	}
}