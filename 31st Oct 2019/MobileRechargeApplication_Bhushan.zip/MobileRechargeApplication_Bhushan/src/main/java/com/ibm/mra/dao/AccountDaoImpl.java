package com.ibm.mra.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ibm.mra.beans.Account;

@Repository("accountDao")
public class AccountDaoImpl implements AccountDao {
	DataSource dataSource;
	NamedParameterJdbcTemplate namedTemplate;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		namedTemplate=new NamedParameterJdbcTemplate(dataSource);
	}

	public Account getAccountDetails(String mobileNo) {
		//Write the query
			long mobile_no=Long.parseLong(mobileNo);
			String qry = "select * from account_entry where mobile_number=:mobile";
			Account acc=null;	
		try {	
		acc= namedTemplate.queryForObject(qry, new MapSqlParameterSource("mobile",mobile_no), new AccountMapper());
		}
		catch(EmptyResultDataAccessException e) {
			//System.out.println("ERROR: Given Account Id Does Not Exists");
		}
		return acc;
		
	}

	public int rechargeAccount(String mobileNo, double rechargeAmount) {
		//Write the query
				String qry = "update account_entry set account_balance=account_balance+ :rechargeAmt where mobile_number= :mobile";
				
				//Execute the query
				return namedTemplate.update(
						qry,
						new MapSqlParameterSource("rechargeAmt",rechargeAmount).addValue("mobile", mobileNo));
				
		
	}
	
	
	
	
	class AccountMapper implements RowMapper<Account>{

		public Account mapRow(ResultSet rs, int rowNum) throws SQLException {
			Account account = new Account();
			
			account.setAccountType(rs.getString("account_type"));
			account.setCustomerName(rs.getString("customer_name"));
			account.setAccountBalance(rs.getDouble("account_balance"));
			
			return account;
		}

		
		
	}
	
	

}
