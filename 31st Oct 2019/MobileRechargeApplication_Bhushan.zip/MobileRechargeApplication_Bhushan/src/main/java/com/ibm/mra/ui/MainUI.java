package com.ibm.mra.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ibm.mra.beans.Account;
import com.ibm.mra.service.AccountService;
import com.ibm.mra.service.AccountServiceImpl;

public class MainUI {

	public static void main(String[] args) throws IOException {

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("appContext.xml");
		AccountService accountService = context.getBean("accountService", AccountServiceImpl.class);

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int option = 0;
		
		do {
			long mobile_no = 0L;
			System.out.println("\nMobile Recharge Application\n");
			System.out.println("1. Account Balance Enquiry Option");
			System.out.println("2. Recharge Account");
			System.out.println("3. exit");

			try {
				option = Integer.parseInt(br.readLine());

			}
			catch(NumberFormatException e) {
				System.out.println("incorrect format!!");
			}
			switch (option) {
			case 1:

				System.out.println("Enter Mobile Number:");
				try {
					mobile_no = Long.parseLong(br.readLine());

				}
				catch(NumberFormatException e) {
					System.out.println("incorrect format for mobile number!!");
				}
				if (!accountService.validateMobileNo(mobile_no)) {
					System.out.println("Mobile number not valid!");
				}
				else {
					Account account = accountService.getAccountDetails(String.valueOf(mobile_no));
					if (account != null) {
						System.out.println("Your current balance is Rs." + account.getAccountBalance());

					}
					else {
						System.out.println("ERROR: Given Mobile No Does Not Exists");
					}

				}
				break;

			case 2:
				double rechargeAmt = 0;
				int updateVal=0;
				try {
					System.out.println("Enter Mobile Number:");
					mobile_no = Long.parseLong(br.readLine());
					System.out.println("Enter Recharge Amount:");
					rechargeAmt = Double.parseDouble(br.readLine());
					
					if (!accountService.validateMobileNo(mobile_no)) {
						System.out.println("Data entered is not valid!");
					}
					else {
						updateVal = accountService.rechargeAccount(String.valueOf(mobile_no), rechargeAmt);
						System.out.println("hjedhbc::"+updateVal);
						if (updateVal > 0) {
							Account rechargedAcc = accountService.getAccountDetails(String.valueOf(mobile_no));
							System.out.println("Your Account Recharged Successfully");
							System.out.println("Hello " + rechargedAcc.getCustomerName() + " , Available Balance is "
									+ rechargedAcc.getAccountBalance());
						} else {
							System.out.println("ERROR: Cannot Recharge Account as Given Mobile No Does Not Exists");
						}

					}
				}  catch(NumberFormatException e) {
					System.out.println("incorrect format!!");
				}
				
				
				break;

			}

		} while (option > 0 && option < 3);

	}

}
