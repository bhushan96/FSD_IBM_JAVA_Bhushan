package com.ibm.payment_wallet.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.ibm.payment_wallet.dao.WalletDaoClass;
import com.ibm.payment_wallet.dao.WalletDaoInterface;
import com.ibm.payment_wallet.model.UserWalletAccount;

public class WalletServiceClass implements WalletServiceInterface {
	WalletDaoInterface dao=new WalletDaoClass();
	public boolean isValidMobileNumber(long mobile_no) {
		// TODO Auto-generated method stub
		String pattern="[7-9]{1}[0-9]{9}";
		return (Pattern.matches(pattern,String.valueOf(mobile_no)));
		
	}

	public boolean isPasswordMatch(String password, String conf_pass) {
		
		return (password.equals(conf_pass));
	}

	public void createWallet(UserWalletAccount user_wallet) {
		dao.createWallet(user_wallet);
		
	}

	public boolean isWalletExist(long mobile_no, String password) {
		return dao.checkWalletDatabase(mobile_no, password);
	}

	public int showBalance(long mobile_no, String password) {

		return dao.showBalance(mobile_no, password);
	}

	public void depositMoney(long mobile_no, String password, int money) {
	
			dao.depositMoney(mobile_no, password, money);
	}

	public void withdrawMoney(long mobile_no, String password, int money) {
		
			dao.withdrawMoney(mobile_no, password, money);
		
	}



	public ArrayList<String> printAllTransaction(long mobile_no, String password) {
		
		return dao.printAllTransaction(mobile_no, password);
	}
}
	
