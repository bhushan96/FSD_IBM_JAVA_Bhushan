package com.ibm.payment_wallet.dao;

import java.util.ArrayList;

import com.ibm.payment_wallet.model.UserWalletAccount;

public interface WalletDaoInterface {

	void createWallet(UserWalletAccount user_wallet);

	boolean checkWalletDatabase(long mobile_no, String password);
	
	int showBalance(long mobile_no, String password);
	void depositMoney(long mobile_no, String password,int money);
	void withdrawMoney(long mobile_no, String password,int money);
	void transactionRecord(long mobile_no, String password,String record);
	ArrayList<String> printAllTransaction(long mobile_no, String password);

}
