package com.ibm.payment_wallet.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.ibm.payment_wallet.model.UserWalletAccount;

public class WalletDaoClass implements WalletDaoInterface {

	public static Connection con=null;
	public WalletDaoClass() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/payment_wallet?serverTimezone=UTC","root","");
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	
	}
	
		
	

	public void createWallet(UserWalletAccount user_wallet) {
	
		try {
			
		
			PreparedStatement ps=con.prepareStatement("insert into userwalletaccount(mobile_number,password,name,address,dob) values(?,?,?,?,? )");
			ps.setLong(1, user_wallet.getMobile_number());
			ps.setString(2, user_wallet.getPassword());
			ps.setString(3, user_wallet.getName());
			ps.setString(4, user_wallet.getAddress());
			ps.setString(5, user_wallet.getDob());
			if(ps.executeUpdate()>0) {
				System.out.println("Wallet created successfully...");
			}
			else {
				System.out.println("Wallet cannot be created...");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}




	public boolean checkWalletDatabase(long mobile_no, String password) {
		boolean result=false;
		try {
			
			
			PreparedStatement ps=con.prepareStatement("select * from userwalletaccount where mobile_number=? and password=?");
			ps.setLong(1, mobile_no);
			ps.setString(2, password);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				result=true;
			}
			else {
				result=false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return result;
	}




	public int showBalance(long mobile_no, String password) {
		// TODO Auto-generated method stub
		int balance=0;
		try {
			
			
			PreparedStatement ps=con.prepareStatement("select balance from userwalletaccount where mobile_number=? and password=?");
			ps.setLong(1, mobile_no);
			ps.setString(2, password);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				balance= rs.getInt("balance");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return balance;
	}




	public void depositMoney(long mobile_no, String password, int money) {
		try {
			
			
			PreparedStatement ps=con.prepareStatement("update userwalletaccount set balance=balance+? where mobile_number=? and password=?");
			ps.setInt(1, money);
			ps.setLong(2, mobile_no);
			ps.setString(3, password);
			
			if(ps.executeUpdate()>0) {
				String transaction="+"+money;
				
				transactionRecord(mobile_no,password,transaction);
				System.out.println("deposited: "+transaction);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}




	public void withdrawMoney(long mobile_no, String password, int money) {
		// TODO Auto-generated method stub
		try {
			
			PreparedStatement ps2=con.prepareStatement("select balance from userwalletaccount where mobile_number=? and password=?");
			ps2.setLong(1, mobile_no);
			ps2.setString(2, password);
			ResultSet rs=ps2.executeQuery();
			if(rs.next()) {
				int balance_before=rs.getInt("balance");
				if((balance_before>money)||(balance_before-money)>0) {
			PreparedStatement ps=con.prepareStatement("update userwalletaccount set balance=balance-? where mobile_number=? and password=?");
			ps.setInt(1, money);
			ps.setLong(2, mobile_no);
			ps.setString(3, password);
			
			if(ps.executeUpdate()>0) {
				String transaction="-"+money;
				
				transactionRecord(mobile_no,password,transaction);
				System.out.println("Withdrawn: "+transaction);
			}
			}
				else {
					System.out.println("Cannot withdraw!!!");
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}




	public void transactionRecord(long mobile_no, String password,String record) {
		// TODO Auto-generated method stub
		String sql="";
		try {
		PreparedStatement ps1=con.prepareStatement("select transactions from userwalletaccount where mobile_number=? and password=?");
		ps1.setLong(1, mobile_no);
		ps1.setString(2, password);
		ResultSet rs=ps1.executeQuery();
		String ck="";
		if(rs.next()) {
			ck=rs.getString("transactions");
			//System.out.println("shshjjjs"+":"+ck);
			if(ck.equals("No Data")) {
				sql="update userwalletaccount set transactions=? where mobile_number=? and password=?";
			}
			else {
				sql="update userwalletaccount set transactions=CONCAT(transactions,';',?) where mobile_number=? and password=?";
			}
		}
		
		PreparedStatement ps2=con.prepareStatement(sql);
		ps2.setString(1, record);
		ps2.setLong(2, mobile_no);
		ps2.setString(3, password);
		int x=ps2.executeUpdate();
		}
		catch(Exception e) {
			
		}
	}




	public ArrayList<String> printAllTransaction(long mobile_no, String password) {
		ArrayList<String> transaction=new ArrayList<String>();
		try {
			PreparedStatement ps1=con.prepareStatement("select transactions from userwalletaccount where mobile_number=? and password=?");
			ps1.setLong(1, mobile_no);
			ps1.setString(2, password);
			ResultSet rs=ps1.executeQuery();
			if(rs.next()) {
				String tran=rs.getString("transactions");
				String tran_arr[]=tran.split(";");
				for(String a:tran_arr) {
					transaction.add(a);
				}
				
			}
			
			
			}
			catch(Exception e) {
				
			}
		return transaction;
	}

}
