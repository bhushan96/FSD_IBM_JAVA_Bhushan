package com.ibm.payment_wallet.service;

import java.util.ArrayList;

import com.ibm.payment_wallet.model.UserWalletAccount;

public interface WalletServiceInterface {

	boolean isValidMobileNumber(long mobile_no);

	boolean isPasswordMatch(String password, String conf_pass);

	void createWallet(UserWalletAccount user_wallet);

	boolean isWalletExist(long mobile_no, String password);
	int showBalance(long mobile_no, String password);
	void depositMoney(long mobile_no, String password,int money);
	void withdrawMoney(long mobile_no, String password,int money);

	ArrayList<String> printAllTransaction(long mobile_no, String password);
	

}
