package com.ibm.payment_wallet.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.payment_wallet.service.WalletServiceClass;
import com.ibm.payment_wallet.service.WalletServiceInterface;

/**
 * Servlet implementation class PaymentController
 */
@WebServlet(urlPatterns= {
		"/payment","/create","/balance","/deposit","/withdraw","/logout","/transfer","/print"
		})
public class PaymentController extends HttpServlet {
	WalletServiceInterface service;
 public PaymentController() {
       
    }

	
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		service=new WalletServiceClass();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String path=request.getServletPath();
		//System.out.println(path);
		PrintWriter pw=response.getWriter();
		boolean b=false;
		int balance=0;
		Object sess=request.getSession().getAttribute("mobile_no");
		
		switch(path) {
		
			
		case "/create":
			
			b=service.createWallet(request, response);
			if(b) {
				pw.println("Wallet created Successfully...");
				request.getRequestDispatcher("login.jsp").include(request,response);
			}
			else {
				pw.println("Error creating wallet! Try Again!");
				request.getRequestDispatcher("createWallet.jsp").include(request,response);
			}
			
			
			break;
		
		case "/balance":
			//int bal=(Integer)request.getSession().getAttribute("balance");
			//request.getRequestDispatcher("balance.jsp").forward(request,response);
			if(sess!=null) {
			balance=service.showBalance(request, response);
			request.getSession().setAttribute("balance",balance);
			request.getRequestDispatcher("balance.jsp").include(request,response);
			}else {
				pw.println("You have to Login first!");
				request.getRequestDispatcher("index.jsp").include(request,response);
			}
			
			break;
	
		case "/logout":
			if(sess!=null) {
				request.getSession().invalidate();
				pw.println("Logged out successfully...");
				request.getRequestDispatcher("login.jsp").include(request,response);
			}
			else {
				pw.println("You have to Login first!");
				request.getRequestDispatcher("index.jsp").include(request,response);
			}
				break;
		case "/deposit":
			if(sess!=null) {
			String deposit_message=service.depositMoney(request, response);
			
			request.getRequestDispatcher("balance").forward(request,response);	
			pw.println("<br>"+deposit_message);
			}
			else {
				pw.println("You have to Login first!");
				request.getRequestDispatcher("index.jsp").include(request,response);
			}
			break;
		case "/withdraw":
			if(sess!=null) {
			String withdraw_message=service.withdrawMoney(request, response);
			
			request.getRequestDispatcher("balance").forward(request,response);	
			}
			else {
				pw.println("You have to Login first!");
				request.getRequestDispatcher("index.jsp").include(request,response);
			}
			//pw.println("<br>"+withdraw_message);
			break;
			
		case "/transfer":
			if(sess!=null) {
			String transfer_message=service.transferMoney(request, response);
			
			request.getRequestDispatcher("balance").forward(request,response);
			}
			else {
				pw.println("You have to Login first!");
				request.getRequestDispatcher("index.jsp").include(request,response);
			}
			break;
			
		case "/print":
			if(sess!=null) {
			service.printAllTransaction(request,response);
			request.getRequestDispatcher("printAllTransaction.jsp").forward(request,response);
			}
			else {
				pw.println("You have to Login first!");
				request.getRequestDispatcher("index.jsp").include(request,response);
			}
			
			break;
			
		
		default:
			b=service.isWalletExist(request, response);
			if(b) {
				pw.println("Successfully Logged in...");
			balance=service.showBalance(request, response);
			request.getSession().setAttribute("balance",balance);
				request.getRequestDispatcher("balance.jsp").include(request,response);
			}else {
				pw.println("Username or Password Invalid or the account does not exist...");
				request.getRequestDispatcher("login.jsp").include(request,response);
				
			}
			break;
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
