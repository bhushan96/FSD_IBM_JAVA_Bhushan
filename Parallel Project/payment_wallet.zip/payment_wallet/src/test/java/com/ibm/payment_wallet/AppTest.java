package com.ibm.payment_wallet;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.Connection;

import org.junit.BeforeClass;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import com.ibm.payment_wallet.dao.WalletDaoClass;
import com.ibm.payment_wallet.dao.WalletDaoInterface;
import com.ibm.payment_wallet.model.UserWalletAccount;

@TestInstance(Lifecycle.PER_CLASS)
public class AppTest {
	WalletDaoInterface dao=new WalletDaoClass();
	
	Connection dbcon = WalletDaoClass.con;
	UserWalletAccount user_wallet = new UserWalletAccount(7878787878L, "qwerty", "qwerty", "23/07/1990", "Delhi");;

	@Test
	@Disabled
	void testWallet() {
		
		dao=new WalletDaoClass();
		boolean a = dao.createWallet(user_wallet); // test for create wallet
		assertTrue(a);
	}

	@Test
	@Disabled
	void testShowBalance() {
		//dao = new WalletDaoClass();
		int expected = 0;
		int actual = dao.showBalance(7878787878L, "qwerty"); // test for show balance
		assertEquals(expected, actual);
	}

	@Test
	void testDepositMoney() {
		//dao = new WalletDaoClass();
		String deposit = dao.depositMoney(7878787878L, "qwerty", 1000);
		String expdep = "1000 deposited in wallet on 21/10/2019"; // test for depositMoney
		assertEquals(expdep, deposit);

	}

	@Test
	void testWithdrawMoney() {
		//dao = new WalletDaoClass();
		String withdraw = dao.withdrawMoney(7878787878L, "qwerty", 500);
		String expdep = "500 withdrawn from wallet on 21/10/2019"; // test for withdrawMoney
		assertEquals(expdep, withdraw);

	}
	
	@Test
	void testTransferMoney() {
		//dao = new WalletDaoClass();
		String transfer=dao.transferMoney(7878787878L, "qwerty", 7896089471L, 250);
		String expected="250 transferred to wallet 7896089471 on 21/10/2019";
		assertEquals(expected, transfer);
	}

}