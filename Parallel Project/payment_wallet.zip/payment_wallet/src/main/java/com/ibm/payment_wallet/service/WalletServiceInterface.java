package com.ibm.payment_wallet.service;

import java.util.ArrayList;

import com.ibm.payment_wallet.model.UserWalletAccount;

public interface WalletServiceInterface {

	boolean isValidMobileNumber(long mobile_no);

	boolean isPasswordMatch(String password, String conf_pass);

	boolean createWallet(UserWalletAccount user_wallet);

	boolean isWalletExist(long mobile_no, String password);
	int showBalance(long mobile_no, String password);
	String depositMoney(long mobile_no, String password,int money);
	String withdrawMoney(long mobile_no, String password,int money);
	boolean passwordValidate(long mobile_no,String password);
	String transferMoney(long sender_mobile_no,String password,long receiver_mobile_no,int money);

	ArrayList<String> printAllTransaction(long mobile_no, String password);
	

}
